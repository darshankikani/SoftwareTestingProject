const firebaseConfig = {
  apiKey: "AIzaSyD4sIZJxC7rGwFKw13Z9rKxw7H2t_Uh1EY",
  authDomain: "carpool-e8b68.firebaseapp.com",
  databaseURL: "https://carpool-e8b68-default-rtdb.firebaseio.com",
  projectId: "carpool-e8b68",
  storageBucket: "carpool-e8b68.appspot.com",
  messagingSenderId: "682992011510",
  appId: "1:682992011510:web:bfc3c78c2a96d20649c4d7",
  measurementId: "G-BH2CL0KYFK"
};
 firebase.initializeApp(firebaseConfig);
	
	function register(){	
		debugger;
		var nm = document.getElementById("name");
		var id = document.getElementById("sid");
		var email = document.getElementById("em");
		var password = document.getElementById("pass");
		var cpd = document.getElementById("cpwd");
		
		firebase.database().ref("Registration").set({
		Sname:nm.value,
		Sid:id.value,
		Email:email.value,
		Password:password.value,
		CPassword:cpd.value
      });

		const auth = firebase.auth();
		const promise = auth.createUserWithEmailAndPassword(email.value,password.value).then(user=>{
			if (user)
			{
				alert("Data Saved successfully");
			}
		}).catch(e => alert(e.message));
		//window.location.href="signup.html";
		document.getElementById("reg").reset();
	}
	
	
	function login(){
		
		var email = eid.value;
        var password = pwd.value;
		//alert(email);
		//alert(password);
		
		

	 const auth = firebase.auth();

        //sign in with firebase auth
        auth.signInWithEmailAndPassword(email.value, password.value).then(user =>{
            alert("Login Successful :)");
        }).catch(err => {
            alert(err.message);
        });
	}
	