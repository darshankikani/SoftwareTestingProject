const { Builder, By, until } = require("selenium-webdriver");

const login ='file:///D:/Sem4/Stesting/project/index.html';
const signup = 'file:///D:/Sem4/Stesting/project/index.html';
const login_email = 'hp@gmail.com';
const login_password = '123456';

async function checkSignup() {
    let driver;
    try {
        console.log('Test 2:');

        driver = await new Builder().forBrowser("firefox").build();
        await driver.get(signup);
        await driver.findElement(By.id('name')).sendKeys('John');
        await driver.findElement(By.id('sid')).sendKeys('2091176');
        await driver.findElement(By.id('em')).sendKeys('john@gmail.com');
        await driver.findElement(By.id('pass')).sendKeys('123456');
        await driver.findElement(By.id('cpwd')).sendKeys('123456');
        console.log(`Sign up with email as john@gmail.com and password as 123456`);
        await driver.findElement(By.tagName('button')).click();
        let status = await driver.wait(until.urlContains('file:///D:/Sem4/Stesting/project/index.html'), 3000);
        if (status) {
            console.log('Test Case Passed');
        }
    } catch (error) {
        alert("Abs");
        console.log('Test Failed !');
    } finally {
        //driver.quit();
    }
}

//checkSignup();

async function checkLogin() {
    let driver;
    try {
        console.log('Test 1:');
        console.log(`Login with email as ${login_email} and password as ${login_password}`);
        driver = await new Builder().forBrowser("firefox").setAlertBehavior('accept').build();
       
        await driver.get(login);
        await driver.findElement(By.id("eid")).sendKeys(login_email);
        await driver.findElement(By.id("pwd")).sendKeys(login_password);
        await driver.findElement(By.tagName('button')).click();
        let status = await driver.wait(until.urlContains('file:///D:/Sem4/Stesting/project/index.html'), 3000);
        if (status) {
            console.log('Test Case Passed');
        }
    } catch (e) {
        console.log('Test Failed !');
    } finally {
      //  driver.quit();
    }

}

checkLogin().finally(() => {

    checkSignup();
});
